from mmcv.utils import Registry

SA_MODULES = Registry('point_sa_module')
